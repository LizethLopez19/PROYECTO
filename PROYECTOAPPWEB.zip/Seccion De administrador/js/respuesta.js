function validarFormulario(){
    let x= document.forms["contact"].value;
if(x===""){
    alert("SE HAN REGISTRADO SUS RESPUESTAS");
    return false;
}
}